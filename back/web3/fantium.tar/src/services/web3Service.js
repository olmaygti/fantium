const Web3 = require('web3');
// const { IpfsService } = require('./ipfsService.js');

const tokenContractAbi = require('../../abis/fantiumToken.json');

class Web3Service {
	constructor(wsConnection) {
		const provider = wsConnection
			? new Web3.providers.WebsocketProvider(process.env.RPC_URL)
			: new Web3.providers.HttpProvider(`http://${process.env.RPC_URL}`);

		this.web3 = new Web3(provider);
	}

	async mintBatch(address, tokensDetails) {
		console.log('minting ', tokensDetails);
		const ipfsService = new IpfsService();

		const cids = await Promise.all(tokensDetails.map(async ({ assetFile, metadata }) => (
			ipfsService.storeAsset(metadata, assetFile)
		)));

		const cidsCallData = this.web3.utils.utf8ToHex(cids.join(','));

		const currentTokenNumberber = await this.totalSupply();
		const tokenIds = [...Array(tokensDetails.length)].map((_, idx) => Number(currentTokenNumber) + idx);
		const tokenAmounts = [...Array(tokensDetails.length)].map(() => 1);

		await this.web3.eth.accounts.wallet.add(process.env.PRIV_KEY);
		const contract = this.getTokenContract();

		const txResult = await contract.methods.mintBatch(address, tokenIds, tokenAmounts, cidsCallData).send({ from: process.env.PUB_KEY, gas: 3000000 });
		console.log('txResult ', txResult.events);

		return tokensDetails.map((token, idx) => ({
			...token.metadata.properties,
			cid: cids[idx],
			tokenId: Number(currentTokenNumber) + idx,
		}));
	}

	getTokenContract() {
		return new this.web3.eth.Contract(tokenContractAbi, process.env.TOKEN_ADDRESS);
	}
}

module.exports = { Web3Service };
