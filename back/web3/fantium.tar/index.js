const workers = require('./src/workers');

const { Web3Service } = require('./src/services/web3Service');


const envFile = process.env.LOCAL_ENV ? '.env.local' : '.env';
console.log('env file ', envFile);

require('dotenv').config({ path: envFile });

console.log('loaded ', process.env.RPC_URL);

async function doStuff() {
	// await Promise.all(workers.concat([{
	// 	async run() {
	// 		const service = new Web3Service();
	// 		console.log('running');
	// 		setInterval(async () => {
	// 			console.log('Store balance ', await service.getEthBalance(process.env.STORE_ADDRESS));
	// 		}, 60000);
	// 	},
	// }]).map((it) => it.run()));
	await Promise.all(workers.map((it) => it.run()));
}

doStuff();
